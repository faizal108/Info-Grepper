This python script focuses on retreving all the webpages links from a giver Url

The link can also be present inside a button or an action

Libraries needed are SSL, urllib and BeautifulSoup

The program access the website and returns all the links present in the website</p>
